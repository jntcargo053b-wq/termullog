# termullog
jarak dan waktu
